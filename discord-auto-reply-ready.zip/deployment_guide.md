# دليل استضافة مشروع Discord Auto-Reply Manager

## 1. مقدمة

يهدف هذا الدليل إلى توفير إرشادات شاملة حول كيفية استضافة ونشر تطبيق Discord Auto-Reply Manager. هذا التطبيق هو عبارة عن "selfbot" يقوم بالرد تلقائيًا على رسائل محددة في قنوات Discord بناءً على قواعد محددة مسبقًا. يعتمد التطبيق على Node.js وقاعدة بيانات PostgreSQL.

**ملاحظة هامة**: استخدام توكن حساب مستخدم (selfbot) يخالف شروط خدمة Discord. هذا الدليل مخصص للأغراض التعليمية فقط.

## 2. المتطلبات الأساسية

قبل البدء بعملية الاستضافة، تأكد من توفر المتطلبات التالية:

*   **خادم افتراضي خاص (VPS)**: خادم Linux (مثل Ubuntu) مع صلاحيات الجذر (root access).
*   **Docker و Docker Compose**: سيتم استخدام Docker لتغليف التطبيق وقاعدة البيانات، و Docker Compose لإدارة الخدمات.
*   **عميل SSH**: للاتصال بالخادم الخاص بك (مثل PuTTY لنظام Windows أو Terminal لنظامي macOS/Linux).
*   **اسم نطاق (Domain Name)**: اختياري، ولكن يوصى به للوصول إلى التطبيق عبر عنوان URL سهل التذكر.
*   **معرفة أساسية بـ Linux و Docker**.

## 3. إعداد البيئة المحلية (اختياري)

يمكنك تشغيل المشروع محليًا باستخدام Docker Compose للتأكد من أن كل شيء يعمل بشكل صحيح قبل النشر:

1.  **انتقل إلى مجلد المشروع**:
    ```bash
    cd /home/ubuntu/discord-auto-reply/discord-auto-reply
    ```
2.  **تشغيل Docker Compose**:
    ```bash
    docker compose up --build
    ```
    سيقوم هذا الأمر ببناء صورة Docker للتطبيق وتشغيل حاوية التطبيق وحاوية PostgreSQL. قد يستغرق الأمر بعض الوقت في المرة الأولى.
3.  **الوصول إلى التطبيق**: بمجرد تشغيل الحاويات، يمكنك الوصول إلى واجهة الويب للتطبيق عبر `http://localhost:3000`.

## 4. التحضير للاستضافة

لقد قمت بتجهيز ملفات Docker اللازمة للمشروع:

*   **`Dockerfile`**: يحدد كيفية بناء صورة Docker لتطبيق Node.js الخاص بك. يتضمن تثبيت Node.js، نسخ ملفات التطبيق، وتحديد أمر التشغيل.
*   **`docker-compose.yml`**: يحدد الخدمات (التطبيق وقاعدة البيانات) وكيفية ربطها ببعضها البعض. كما يقوم بتعيين متغيرات البيئة اللازمة لقاعدة البيانات والتطبيق.
*   **`.env`**: ملف لمتغيرات البيئة الحساسة مثل `DATABASE_URL` و `PORT`. يجب ألا يتم تضمينه في نظام التحكم في الإصدار (Git) ويجب إعداده يدويًا على الخادم.

## 5. خطوات النشر على خادم افتراضي خاص (VPS)

### 5.1. الاتصال بالخادم

استخدم SSH للاتصال بالخادم الخاص بك:

```bash
ssh user@your_vps_ip_address
```
استبدل `user` باسم المستخدم الخاص بك و `your_vps_ip_address` بعنوان IP الخاص بالخادم.

### 5.2. تثبيت Docker و Docker Compose

إذا لم يكن Docker و Docker Compose مثبتين بالفعل على الخادم الخاص بك، يمكنك تثبيتهما باتباع الخطوات التالية (لأنظمة Ubuntu/Debian):

1.  **تحديث حزم النظام**:
    ```bash
    sudo apt update && sudo apt upgrade -y
    ```
2.  **تثبيت Docker**:
    ```bash
    sudo apt install docker.io -y
    sudo systemctl start docker
    sudo systemctl enable docker
    ```
3.  **إضافة المستخدم الحالي إلى مجموعة Docker (اختياري، ولكن يوصى به)**:
    ```bash
    sudo usermod -aG docker $USER
    newgrp docker
    ```
    قد تحتاج إلى إعادة تسجيل الدخول لتطبيق التغييرات.
4.  **تثبيت Docker Compose**:
    ```bash
    sudo apt install docker-compose -y
    ```

### 5.3. نقل ملفات المشروع

انقل مجلد المشروع `discord-auto-reply` إلى الخادم الخاص بك. يمكنك استخدام `scp` أو `rsync`:

```bash
scp -r /home/ubuntu/discord-auto-reply/discord-auto-reply user@your_vps_ip_address:/home/user/
```
استبدل `/home/ubuntu/discord-auto-reply/discord-auto-reply` بالمسار المحلي لمجلد المشروع، و `user@your_vps_ip_address:/home/user/` بالمسار على الخادم حيث تريد وضع المشروع.

### 5.4. إعداد متغيرات البيئة

1.  **انتقل إلى مجلد المشروع على الخادم**:
    ```bash
    cd /home/user/discord-auto-reply
    ```
2.  **إنشاء ملف `.env`**: انسخ ملف `.env.example` إلى `.env`:
    ```bash
    cp .env.example .env
    ```
3.  **تعديل ملف `.env`**: افتح الملف باستخدام محرر نصوص (مثل `nano` أو `vim`) وقم بتحديث `DATABASE_URL` ليتناسب مع إعدادات PostgreSQL في `docker-compose.yml`:
    ```bash
    nano .env
    ```
    تأكد من أن `DATABASE_URL` يشير إلى خدمة `postgres` داخل شبكة Docker Compose:
    ```
    DATABASE_URL=postgresql://discord_user:discord_password@postgres:5432/discord_bot
    PORT=3000
    LOG_LEVEL=info
    ```
    **ملاحظة**: `discord_user` و `discord_password` و `discord_bot` هي القيم الافتراضية المحددة في `docker-compose.yml`. يمكنك تغييرها في `docker-compose.yml` و `.env` إذا أردت.

### 5.5. تشغيل التطبيق

من داخل مجلد المشروع على الخادم، قم بتشغيل Docker Compose:

```bash
docker compose up -d --build
```
*   `up`: يقوم بإنشاء وتشغيل الحاويات.
*   `-d`: لتشغيل الحاويات في الخلفية (detached mode).
*   `--build`: لإعادة بناء صور Docker (مفيد بعد أي تغييرات في الكود أو Dockerfile).

يمكنك التحقق من حالة الحاويات باستخدام:

```bash
docker compose ps
```

### 5.6. إعداد قاعدة البيانات

وفقًا لملف `README.md`، تحتاج إلى إنشاء جداول قاعدة البيانات يدويًا. يمكنك الاتصال بقاعدة بيانات PostgreSQL داخل حاوية Docker وتشغيل أوامر SQL:

1.  **الحصول على اسم حاوية PostgreSQL**:
    ```bash
    docker ps
    ```
    ابحث عن الحاوية التي تحتوي على `postgres` في اسمها (عادةً `discord-auto-reply-db`).
2.  **الاتصال بقاعدة البيانات داخل الحاوية**:
    ```bash
    docker exec -it discord-auto-reply-db psql -U discord_user -d discord_bot
    ```
    سيطلب منك كلمة المرور (`discord_password`).
3.  **تشغيل أوامر SQL لإنشاء الجداول**:
    ```sql
    CREATE TABLE IF NOT EXISTS discord_accounts (
      id SERIAL PRIMARY KEY,
      label TEXT NOT NULL,
      token TEXT NOT NULL,
      token_masked TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'idle',
      username TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS discord_rules (
      id SERIAL PRIMARY KEY,
      account_id INTEGER NOT NULL,
      channel_id TEXT NOT NULL,
      trigger_message TEXT NOT NULL,
      reply_message TEXT NOT NULL,
      match_type TEXT NOT NULL DEFAULT 'contains',
      enabled BOOLEAN NOT NULL DEFAULT TRUE,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS discord_reply_logs (
      id SERIAL PRIMARY KEY,
      account_id INTEGER NOT NULL,
      rule_id INTEGER NOT NULL,
      channel_id TEXT NOT NULL,
      trigger_content TEXT NOT NULL,
      replied_with TEXT NOT NULL,
      replied_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    ```
    بعد لصق الأوامر، اكتب `\q` للخروج من `psql`.

## 6. إعداد خادم الويب العكسي (Nginx) (اختياري، ولكن يوصى به)

للوصول إلى التطبيق عبر اسم نطاق وتأمين الاتصال باستخدام HTTPS، يوصى بإعداد Nginx كخادم وكيل عكسي.

1.  **تثبيت Nginx**:
    ```bash
    sudo apt install nginx -y
    sudo systemctl start nginx
    sudo systemctl enable nginx
    ```
2.  **إنشاء ملف تهيئة Nginx للمشروع**:
    ```bash
    sudo nano /etc/nginx/sites-available/discord-auto-reply
    ```
    أضف المحتوى التالي (استبدل `your_domain.com` بنطاقك):
    ```nginx
    server {
        listen 80;
        server_name your_domain.com www.your_domain.com;

        location / {
            proxy_pass http://localhost:3000;
            proxy_http_version 1.1;
            proxy_set_header Upgrade $http_upgrade;
            proxy_set_header Connection 'upgrade';
            proxy_set_header Host $host;
            proxy_cache_bypass $http_upgrade;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
        }
    }
    ```
3.  **تفعيل التهيئة**:
    ```bash
    sudo ln -s /etc/nginx/sites-available/discord-auto-reply /etc/nginx/sites-enabled/
    ```
4.  **اختبار تهيئة Nginx وإعادة تحميله**:
    ```bash
    sudo nginx -t
    sudo systemctl reload nginx
    ```
5.  **تأمين HTTPS باستخدام Certbot (اختياري، ولكن يوصى به بشدة)**:
    ```bash
    sudo apt install certbot python3-certbot-nginx -y
    sudo certbot --nginx -d your_domain.com -d www.your_domain.com
    ```
    اتبع التعليمات التي تظهر على الشاشة.

## 7. مراقبة التطبيق

*   **عرض سجلات التطبيق**: يمكنك عرض سجلات حاوية التطبيق باستخدام:
    ```bash
    docker compose logs -f app
    ```
*   **إعادة تشغيل التطبيق**: إذا قمت بتغيير أي شيء في الكود أو الإعدادات، يمكنك إعادة بناء وتشغيل التطبيق:
    ```bash
    docker compose down && docker compose up -d --build
    ```

## 8. الخلاصة

باتباع هذه الخطوات، يجب أن يكون تطبيق Discord Auto-Reply Manager الخاص بك يعمل على الخادم. تذكر دائمًا مراجعة سجلات التطبيق وقاعدة البيانات لأي مشاكل قد تواجهها.

---
