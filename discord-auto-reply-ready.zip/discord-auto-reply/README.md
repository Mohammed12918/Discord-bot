# Discord Auto-Reply Manager

أداة لإدارة ردود Discord التلقائية — selfbot يرد على رسائل محددة في قنوات محددة.

> ⚠️ استخدام توكن حساب مستخدم (selfbot) يخالف شروط خدمة Discord. للأغراض التعليمية فقط.

## المتطلبات

- Node.js v20 أو أحدث
- قاعدة بيانات PostgreSQL

## التشغيل

### 1. إعداد متغيرات البيئة

```bash
cp .env.example .env
```

عدّل ملف `.env` وضع رابط قاعدة البيانات:

```
DATABASE_URL=postgresql://user:password@localhost:5432/discord_bot
PORT=3000
```

### 2. إنشاء جداول قاعدة البيانات

شغّل هذا SQL على قاعدة البيانات الخاصة بك:

```sql
CREATE TABLE IF NOT EXISTS discord_accounts (
  id SERIAL PRIMARY KEY,
  label TEXT NOT NULL,
  token TEXT NOT NULL,
  token_masked TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'idle',
  username TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS discord_rules (
  id SERIAL PRIMARY KEY,
  account_id INTEGER NOT NULL,
  channel_id TEXT NOT NULL,
  trigger_message TEXT NOT NULL,
  reply_message TEXT NOT NULL,
  match_type TEXT NOT NULL DEFAULT 'contains',
  enabled BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS discord_reply_logs (
  id SERIAL PRIMARY KEY,
  account_id INTEGER NOT NULL,
  rule_id INTEGER NOT NULL,
  channel_id TEXT NOT NULL,
  trigger_content TEXT NOT NULL,
  replied_with TEXT NOT NULL,
  replied_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```

### 3. تشغيل التطبيق

```bash
PORT=3000 DATABASE_URL=your_connection_string node dist/index.mjs
```

أو إذا أنشأت ملف `.env` استخدم dotenv:

```bash
node --env-file=.env dist/index.mjs
```

افتح المتصفح على: http://localhost:3000

## الاستخدام

1. **Accounts** — أضف حساب Discord بالـ Label والـ Token، ثم اضغط Start
2. **Rules** — حدّد قاعدة: Channel ID + الرسالة المستهدفة + الرد + نوع المطابقة
3. **Logs** — راجع سجل الردود التلقائية

## نوع المطابقة

- `contains` — الرسالة تحتوي على النص (الافتراضي)
- `exact` — الرسالة مطابقة تماماً
- `startsWith` — الرسالة تبدأ بالنص
